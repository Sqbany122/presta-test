<html>
    <head>
        <style>
            body {
                font-family: monospace;
                font-size: 12px;
            }
            .alert {
                position: relative;
                padding: 0.75rem 1.25rem;
                margin-bottom: 1rem;
                border: 1px solid transparent;
                border-radius: 0.25rem;
            }
            .alert-success {
                color: #155724;
                background-color: #d4edda;
                border-color: #c3e6cb;
            }
            table {
                margin-top: 1rem;
                margin-bottom: 1rem;
                font-size: 0.75rem;
                border: none!important;
                background: none;
                border-collapse: collapse;
                border-spacing: 0;
            }
            table td, table th {
                padding: 0.375rem 0.75rem;
                vertical-align: middle;
                border: none;
            }
            table th {
                vertical-align: middle;
                background-color: #333;
                color: #fff;
                font-weight: 700;
            }
            table tr:nth-of-type(odd) {
                background-color: rgba(0, 0, 0, 0.05);
            }
            table tr:hover {
                color: #212529;
                background-color: rgba(0, 0, 0, 0.2);
            }
            .alert {
                position: relative;
                padding: 0.75rem 1.25rem;
                margin-bottom: 1rem;
                border: 1px solid transparent;
                border-radius: 0.25rem;
            }
            .alert-success {
                color: #155724;
                background-color: #d4edda;
                border-color: #c3e6cb;
            }
        </style>
    </head>
    <body>
        <div class="main">